from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel, Field
from playwright.async_api import async_playwright, Browser, Playwright
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
import os
import string
import random
import subprocess
import platform

# Rate Limiter setup (10 requests per 10 minutes per IP)
limiter = Limiter(key_func=get_remote_address)

# Global variables to maintain persistent browser
playwright_instance: Playwright = None
browser_instance: Browser = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global playwright_instance, browser_instance
    print("Starting Playwright (Optimized mode)...")
    playwright_instance = await async_playwright().start()
    browser_instance = await playwright_instance.chromium.launch(headless=True)
    yield
    print("Shutting down Playwright...")
    await browser_instance.close()
    await playwright_instance.stop()

app = FastAPI(lifespan=lifespan)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

def generate_id(length=8):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

class PasteRequest(BaseModel):
    # Strong server checks: Must be between 1 and 100,000 characters
    content: str = Field(..., min_length=1, max_length=100000)

@app.get("/", response_class=HTMLResponse)
async def serve_frontend():
    return FileResponse(os.path.join(os.path.dirname(__file__), "index.html"))

@app.post("/api/paste")
@limiter.limit("10/10minutes")
async def create_paste(request: Request, paste_req: PasteRequest):
    if not browser_instance:
        raise HTTPException(status_code=500, detail="Browser not initialized")

    try:
        # Step 1: Obfuscate the Lua code using Prometheus
        temp_id = generate_id(6)
        temp_input = f"temp_input_{temp_id}.lua"
        temp_output = f"temp_output_{temp_id}.lua"
        
        with open(temp_input, "w", encoding="utf-8") as f:
            f.write(paste_req.content)
            
        if platform.system() == "Windows":
            lua_exe = os.path.join(os.path.dirname(__file__), "luaenv", "lua5.1.exe")
        else:
            lua_exe = "lua5.1" # On Linux, use the system installed lua5.1
            
        cli_lua = os.path.join(os.path.dirname(__file__), "Prometheus-master", "Prometheus-master", "cli.lua")
        
        process = subprocess.run(
            [lua_exe, cli_lua, "--preset", "Medium", "--LuaU", temp_input, "--out", temp_output],
            capture_output=True,
            text=True
        )
        
        if process.returncode != 0:
            if os.path.exists(temp_input): os.remove(temp_input)
            raise HTTPException(status_code=400, detail=f"Failed to obfuscate Lua code. Ensure it is valid Lua. Error: {process.stderr}")
            
        # Read the obfuscated result
        with open(temp_output, "r", encoding="utf-8") as f:
            obfuscated_content = f.read()
            
        # Clean up temp files
        if os.path.exists(temp_input): os.remove(temp_input)
        if os.path.exists(temp_output): os.remove(temp_output)
        
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to obfuscate paste.")

    # Create a fresh, lightweight context for this request instead of launching a full browser
    context = await browser_instance.new_context()
    page = await context.new_page()

    # OPTIMIZATION: Block heavy resources but leave CSS/fonts intact to prevent breaking the editor
    async def route_intercept(route):
        if route.request.resource_type in ["image", "media"]:
            await route.abort()
        else:
            await route.continue_()

    await page.route("**/*", route_intercept)

    try:
        await page.goto("https://pastefy.app/", timeout=15000)
        
        try:
            consent_btn = page.get_by_role("button", name="Consent", exact=True)
            await consent_btn.click(timeout=1000)
        except Exception:
            pass # Consent might not appear

        await page.locator("pre").nth(2).click(timeout=5000)
        await page.get_by_role("textbox").nth(1).fill(obfuscated_content) # Using the obfuscated text here!
        
        async with page.expect_popup(timeout=10000) as page1_info:
            await page.get_by_role("button", name="submit").click(timeout=5000)
            await page.get_by_role("link", name="RAW").click(timeout=5000)
            
        page1 = await page1_info.value
        raw_url = page1.url
        return {"url": raw_url}
    except Exception as e:
        print(f"Error during automation: {e}")
        raise HTTPException(status_code=500, detail="Failed to create paste or timed out.")
    finally:
        # Always clean up the context
        await context.close()

if __name__ == "__main__":
    import uvicorn
    # reload=False is required to properly use `lifespan` without zombie browser processes
    uvicorn.run("main:app", host="0.0.0.0", port=8001, reload=False)
