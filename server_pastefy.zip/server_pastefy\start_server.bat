@echo off
echo Installing Python dependencies...
pip install fastapi uvicorn slowapi pydantic playwright

echo Installing Playwright Headless Browser...
playwright install chromium

echo Starting server...
uvicorn main:app --host 0.0.0.0 --port 8001
pause
