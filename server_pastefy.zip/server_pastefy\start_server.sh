#!/bin/bash
echo "Installing Python dependencies..."
pip3 install fastapi uvicorn slowapi pydantic playwright

echo "Installing Playwright Headless Browser & Dependencies..."
python3 -m playwright install chromium
python3 -m playwright install-deps chromium

echo "Checking for Lua 5.1..."
if ! command -v lua5.1 &> /dev/null
then
    echo "Lua 5.1 could not be found. Attempting to install via apt..."
    sudo apt update && sudo apt install -y lua5.1
fi

echo "Starting server..."
python3 -m uvicorn main:app --host 0.0.0.0 --port 8001
