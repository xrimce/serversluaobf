from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, FileResponse, PlainTextResponse
from pydantic import BaseModel, Field
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
import os
import string
import random
import subprocess
import platform

# Rate Limiter setup (10 requests per 10 minutes per IP)
limiter = Limiter(key_func=get_remote_address)

app = FastAPI()
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Ensure pastes directory exists
PASTES_DIR = os.path.join(os.path.dirname(__file__), "pastes")
os.makedirs(PASTES_DIR, exist_ok=True)

def generate_id(length=8):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

class PasteRequest(BaseModel):
    # Strong server checks: Must be between 1 and 100,000 characters
    content: str = Field(..., min_length=1, max_length=100000)

@app.get("/", response_class=HTMLResponse)
async def serve_frontend():
    return FileResponse(os.path.join(os.path.dirname(__file__), "index.html"))

@app.get("/raw/{paste_id}", response_class=PlainTextResponse)
async def get_raw_paste(paste_id: str):
    # Security check to prevent path traversal
    if not paste_id.isalnum():
        raise HTTPException(status_code=400, detail="Invalid paste ID")
    
    file_path = os.path.join(PASTES_DIR, f"{paste_id}.txt")
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Paste not found")
        
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()

@app.post("/api/paste")
@limiter.limit("10/10minutes")
async def create_paste(request: Request, paste_req: PasteRequest):
    try:
        # Step 1: Obfuscate the Lua code using Prometheus
        temp_id = generate_id(6)
        temp_input = f"temp_input_{temp_id}.lua"
        temp_output = f"temp_output_{temp_id}.lua"
        
        with open(temp_input, "w", encoding="utf-8") as f:
            f.write(paste_req.content)
            
        if platform.system() == "Windows":
            lua_exe = os.path.join(os.path.dirname(__file__), "luaenv", "lua5.1.exe")
        else:
            lua_exe = "lua5.1" # On Linux, use the system installed lua5.1
            
        cli_lua = os.path.join(os.path.dirname(__file__), "Prometheus-master", "Prometheus-master", "cli.lua")
        
        process = subprocess.run(
            [lua_exe, cli_lua, "--preset", "Medium", "--LuaU", temp_input, "--out", temp_output],
            capture_output=True,
            text=True
        )
        
        if process.returncode != 0:
            if os.path.exists(temp_input): os.remove(temp_input)
            print(f"Prometheus Error: {process.stderr}")
            raise HTTPException(status_code=400, detail=f"Failed to obfuscate Lua code. Ensure it is valid Lua. Error: {process.stderr}")
            
        # Read the obfuscated result
        with open(temp_output, "r", encoding="utf-8") as f:
            obfuscated_content = f.read()
            
        # Clean up temp files
        if os.path.exists(temp_input): os.remove(temp_input)
        if os.path.exists(temp_output): os.remove(temp_output)

        # Step 2: Save to local disk (Our own Pastefy!)
        paste_id = generate_id(10)
        file_path = os.path.join(PASTES_DIR, f"{paste_id}.txt")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(obfuscated_content)
            
        # Construct the raw URL dynamically based on the server's domain/IP
        base_url = str(request.base_url)
        raw_url = f"{base_url}raw/{paste_id}"
        
        return {"url": raw_url}
        
    except HTTPException as he:
        raise he
    except Exception as e:
        print(f"Error during automation: {e}")
        raise HTTPException(status_code=500, detail="Failed to create paste.")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
